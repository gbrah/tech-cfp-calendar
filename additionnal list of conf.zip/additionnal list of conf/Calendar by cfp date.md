---
markmap:
  initialExpandLevel: 2
---


# OCTOBER 

[Touraine Tech](https://touraine.tech/) 
[📣](http://cfp.Touraine.tech) 
📅 JAN 19-20 2023
📍 TOURS, FRANCE 🇫🇷

## [Commit conf](https://2023.commit-conf.com/en/)
### [📣](https://koliseo.com/events/commit-2023/sessions)
### 📅 APRIL 21-22 2023
### 📍 Madrid, SPAIN 🇪🇸

## [DevFest Pisa](https://kotlinconf.com/)
### [📣](https://sessionize.com/devfest-pisa-2023/)
### 📅 April 1, 2023
### 📍 Pisa, Italy 🇮🇹

## [WebExpo](https://webexpo.net/)
### [📣](https://webexpo.net/call-for-papers/)
### 📅 APRIL 19-21
### 📍 Prague, Czechia 🇨🇿

## [DevSUM]('https://sessionize.com/devsum-2023')
### [📣](https://sessionize.com/devsum-2023/)
### 📅 25-26 MAY 2023
### 📍 Stockholm, SWEDEN 🇸🇪
  
# NOVEMBER 

## [FOSDEM](https://fosdem.org/2023/)
### [📣](https://fosdem.org/2023/news/2022-11-07-accepted-developer-rooms/)
### 📅 FEB 4-5 2023
### 📍 Brussels, BELGIUM 🇧🇪

## [Devoxx Paris]('https://www.devoxx.fr/')
### [📣](https://cfp.devoxx.fr/)
### 📅 APRIL 12-13-14 2023
### 📍 Amsterdam, NETHERLAND 🇳🇱

## [Devoxx UK](https://www.devoxx.co.uk)
### [📣](https://devoxxuk23.cfp.dev/)
### 📅 MAY 10-12 2023
### 📍 LONDON, UK 🇬🇧

## [AppDevCon](https://appdevcon.nl/)
### [📣](https://appdevcon.nl/speakers/cfp/)
### 📅 9-12 MAY 
### 📍 Amsterdam, Netherlands 🇳🇱

## [plSwift/plDroid](https://plswift.com/)
### [📣](https://www.papercall.io/plswift)
### 📅 MAY 30-31 2023
### 📍 Warsaw, Poland 🇵🇱

# DECEMBER 

## [DevFest Paris](https://devfest.gdgparis.com/fr/)
### [📣](https://gospeak.io/cfps/ext/923b54dd-c850-44a4-821d-7224a3d8071c)
### 📅 JAN 14 2020 
### 📍 Paris, FRANCE 🇫🇷

## [Android Makers by droidcon](https://androidmakers.fr/)
### [📣](https://sessionize.com/androidmakers-by-droidcon-2023/)
### 📅 APRIL 27-28 2023
### 📍 Paris, FRANCE 🇫🇷

## [AppBuilder](https://appbuilders.ch/)
### [📣](https://t.co/nlFUyZh86t)
### 📅 16-17 MAY 2022
### 📍 Ascona, Switzerland 🇨🇭

## [MixIT Lyon]('https://mixitconf.org/en/') 
### [📣](https://sessionize.com/mixit2023/)
### 📅 APRIL 13-14 2023
### 📍 Lyon, France 🇫🇷

# JANUARY 

## [Devoxx Poland](https://devoxx.pl/)	 
### [📣](https://devoxxpl23.cfp.dev/)
### 📅 MAY 31 - JUNE 2 2023
### 📍 Krakow, POLAND


# FEBRUARY 

## [iOS Conf SG](https://iosconf.sg/)	
### [📣](https://t.co/eqKUGDyN9D)
### 📅 JAN 12-13 2023
### 📍 SINGAPORE 🇸🇬

## [OpenSource Summit Europe]('https://events.linuxfoundation.org/open-source-summit-north-america/')
### [📣](https://linuxfoundation.smapply.io/prog/open_source_summit_europe_2023/)
### 📅 SEPT 19-21 2023
### 📍 Vancouver, CANADA 🇨🇦


# JULY

## [NDC London](https://ndclondon.com/)
### [📣](https://sessionize.com/ndc-london-2023/)
### 📅 JAN 23-27 2023
### 📍 London, UK 🇬🇧

## [Kotlin conf Amsterdam](https://kotlinconf.com/)
### [📣](https://sessionize.com/kotlinconf-2023/)
### 📅 APRIL 12-13-14 2023
### 📍 Amsterdam, NETHERLAND 🇳🇱

# AUGUST

## [Great International Developer Summit](https://indiaai.gov.in/events/great-international-developer-summit)
### [📣](https://developersummit.wufoo.com/forms/gids-2023-call-for-proposals/)
### 📅 APRIL 25-28 2023
### 📍 Bengaluru, India 🇮🇳 / Online

## [Frenchkit](https://frenchkit.fr/)
### [📣](https://www.papercall.io/frenchkit-2022)
### 📅 SEPT 29-30 2022
### 📍 Paris, FRANCE


### [📣]()
### 📅 
### 📍 