
Hey mobile devops, it’s time to make your whole CI/CD in the cloud !

Do you remember when you were sharing your iOS binaries with  a freshly imported mobile provisionning on your workspace ? 

This is how started mobile continuous integration (CI). Fragmentation exists when you talk about mobile CI with the hardware needed to build and test you app (x86-64, M1, A1X)    . 

Also, you have a lot of variety of app frameworks to build today (KMM, Flutter, React...)

Would you like to see what the famous "Move to Cloud" trend brings to a mobile developer to solve these issues ?

The idea of the talk is to share with you 5 tips to shutdown your Mac mini from your office and start thinking cloud for your Apple app releases

I'll share how to make & simplify your DevOps standard in the Cloud to build iOS, Flutter, KMM Apps.