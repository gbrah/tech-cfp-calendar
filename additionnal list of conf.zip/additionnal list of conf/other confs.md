https://kotlinconf.com/
https://humantalks.com/

[Mobile world congress Shangai](https://www.mwcshanghai.com/)
[📣]
📅 JUN 28-30 2023
📍 Shangai, Chine 🇨🇳

[Viva technology](https://vivatechnology.com/)
[📣]
📅 15 au 17 juin 2022
📍 Paris, France 🇫🇷

[JS Nation Amsterdam](https://jsnation.com/)
[📣]
📅 9 au 10 juin 2022
📍 Amsterdam, Pays-Bas 🇳🇱

[JSCONF EU](https://2022.jsconf.eu/)
[📣]
📅 14 au 15 avril 2022
📍 Berlin, Allemagne 🇩🇪

[JSCONF BE](https://jsconf.be/)
[📣]
📅 22 au 23 septembre 2022
📍 Bruxelles, Belgique 🇧🇪

## [Tech (K)now Day](https://www.techknowday.com/)
### ### [📣](https://sessionize.com/techknow-day-on-IWD2023/)
### ### 📅 MARCH 8 2023
### ### 📍 London, UK 🇩🇪

## [Agile Testing Days](https://agiletestingdays.com/)
### ### [📣]
### ### 📅 NOV 13-16 2023
### ### 📍 Potsdam, Germany 🇩🇪


## [Graphql Summit](https://summit.graphql.com/)
### ### [📣](https://docs.google.com/forms/d/e/1FAIpQLScYpmuJuPkoSxPnpcHRPjx_IKCQ5FwvsXnPTdhsmON_wAubJQ/viewform)
### ### 📅 OCT 10-12 2023
### ### 📍 San Diego, États-Unis 🇺🇸

## [REACT Advanced London](https://reactadvanced.com/)
### ### [📣]
### ### 📅 OCT 20-23 2023
### ### 📍 Londres, Royaume-Uni 🇬🇧

## [QCon San Francisco](https://qconsf.com/)
### ### [📣]
### ### 📅 OCT 2-6 2023
### ### 📍 San Francisco, USA 🇺🇸

## [Serverless Architecture Conference London](https://serverless-architecture.io/)
### ### [📣]
### ### 📅 APR 24-27 2023
### ### 📍 London, UK


## [API World](https://apiworld.co/)
### ### [📣]
### ### 📅 OCT 24 - NOV 2 2023
### ### 📍 San Jose, Californie, États-Unis 🇺🇸 / Online

## [Microservices World](https://microservicesworld.co/)
### ### [📣]
### ### 📅 OCT 24 - NOV 2 2023
### ### 📍 Santa Clara, USA / Online

## [CES]('https://www.ces.tech/') 
### 📅 JAN 9-12, 2024
### 📍 Las Vegas, USA
[GOTO Copenhagen 2022](https://gotocph.com/)
[📣]
📅 OCT 2-6
📍 Copenhague, Danemark 🇩🇰
## [DeveloperWeek](https://www.developerweek.com/)
### [📣]
### 📅 FEB 15 17
### 📍 SAN FRANCISCO, USA / ONLINE
### AdaLoversConf	https://www.adaloversconf.es/schedule
### Strange Loop https://thestrangeloop.com/	
21-22 September
https://thestrangeloop.com/cfp.html
St. Louis, Missouri
📅 Dates : FEB 21-29 2024
📍 Lieu : San Francisco, USA / Online
[ITNEXT Summit](https://www.itnextsummit.com/)
[📣]
📅 27 au 28 avril 2023
📍 Amsterdam, Pays-Bas 🇳🇱



Verytechtrip https://verytechtrip.ovhcloud.com/fr/
📅 Date: FEB 2 2023
📍 Paris, France 🇫🇷


[React Day Norway](https://reactnorway.com/)
Appel à communication : Fermé
25 octobre 2022
📍 Oslo, Norvège 🇳🇴

[Startup Eurasia](https://www.eurasiastartupsummit.com/)
[📣]
📅 MAY 19-21 2023
📍 Bodrum, Turquie 🇹🇷
[odemotion Conference Milan](https://extra.codemotion.com/conference-milan-2023/)
[📣]
📅 OCT 24-27 2023
📍 Milan, Italie 🇮🇹
WWDC 
GOOGLE IO 
MICROSOFT BUILD 
### Android Dev Summit
### [IntelliJ IDEA conf]('https://pages.jetbrains.com/intellij-idea-conf-2022/')
## [Mobile World Congress Barcelona](https://www.mwcbarcelona.com/)
### 📅
### 📍
### [GIT merge Chicago]('https://git-merge.com/') 
### [Mobile world congress]('https://www.mwclasvegas.com/')
[Tech Up for Women](https://techupforwomen.com/)
[📣]
📅 16 au 17 novembre 2022
📍 New York, États-Unis 🇺🇸

[Darwin’s Circle](https://www.darwinscircle.com/conferences)
[📣]
📅 NOV 9 2023
📍 Vienne, Autriche 🇦🇹

[Fintech Growth Summit](https://fintechgrowthsummit.com/)
[📣]
📅 Le 18 mai 2022
📍 Londres, Royaume-Uni 🇬🇧

--------------------------------------------------------

[YOW! Sydney](https://yowconference.com/sydney/)
[📣]
📅 6 au 7 décembre 2022
📍 Sydney, Australie 🇦🇺

[Global Summit for Node.js'23](https://events.geekle.us/nodejs/#!)
[📣]
📅 27 au 29 mars 2023
📍 En ligne


[Advent of code](https://adventofcode.com/)
[📣]
📅 1er au 25 décembre 2022
📍 En ligne
[Women Who Code Mobile Summit](https://www.womenwhocode.com/mobile-summit)
Appel à communication : 
23 septembre 2022
📍 En ligne

[QCon Guangzhou](https://qcongz.com/)
Appel à communication : Fermé
27-29 mai 2022
📍 Guangzhou, Chine 🇨🇳

[CityJS Conference Singapore](https://cityjsconf.sg/)
Appel à communication : Ouvert
30 juin - 1er juillet 2022
📍 Singapour 🇸🇬

[JavasScript & Friends Conference 2022](https://js-friends.com/)
Appel à communication : Ouvert jusqu'au 11 avril 2022
8-9 septembre 2022
📍 Paris, France 🇫🇷
[TYPO3Camp Schweiz](https://www.typo3camp.ch/)
[📣]
📅 27 au 28 mai 2022
📍 Rapperswil-Jona, Suisse 🇨🇭

[HalfStack Newquay](https://halfstackconf.com/newquay/)
[📣]
📅 Le 12 août 2022
📍 Newquay, Royaume-Uni 🇬🇧


[JSCONF US](https://2022.jsconf.us/
[📣]
📅 15 au 16 septembre 2022
📍 Washington, États-Unis 🇺🇸


[Conference for kotliners Budapest](https://10times.com/conference-for-kotliners)
[📣]
📅 14 au 15 octobre 2022
📍 Budapest, Hongrie 🇭🇺
[Networking @Scale 2022](https://networkingatscale.com/)
[📣]
📅 
📍 San Francisco, Californie, États-Unis 🇺🇸

## [JS World]('https://jsworldconference.com/')
### [📣]
### 📅 8-9-10 FEB 2023
### 📍 Amsterdam, NETHERLANDS
### React Alicante	https://ti.to/reactalicante/react-alicante-2022/en
### React India 
### React Finland 2022
### RenderATL 
### International Javascript Conference	
### Atlanta 
https://www.refactr.tech/

[QCon New York](https://plus.qconferences.com/)
[📣]
📅 13-15 JUNE
📍 New York, USA
[QCon New York](https://plus.qconferences.com/)
[📣]
📅 13-15 JUNE
📍 New York, USA

[YOW! London](https://yowconference.com/london/)
[📣]
📅 14 au 15 septembre 2022
📍 Londres, Royaume-Uni 🇬🇧


[Angular Day](https://2022.angularday.it/)
[📣]
📅 OCT 7 2022
📍 Verona, Italie 🇮🇹

[NG DE](https://ng-de.org/)
[📣]
📅 23 au 24 février 2022
📍 Berlin, Allemagne 🇩🇪


[dot JS](https://www.dotjs.io/)
[📣]
📅 8 au 9 décembre 2022
📍 Paris, France 🇫🇷

[dot CSS](https://www.dotcss.io/)
[📣]
📅 6 au 7 décembre 2022
📍 Paris, France 🇫🇷

[Serverless Architecture Conference Berlin](https://serverless-architecture.io/)
[📣]
📅 
📍 

[International Javascript Conference Munich](https://javascript-conference.com/)
[📣]
📅 OCT 23-27 2023
📍 Munich, Allemagne 🇩🇪

[CityJS Conference ](https://cityjsconf.org/nigeria)
[📣]
📅 23 au 24 septembre 2022
📍 

[JavaScript, Angular, React & HTML & CSS Days](https://www.webcongress.com/javascript-milan-2022/)
[📣]
📅 29 au 30 septembre 2022
📍 Milan, Italie 🇮🇹

[Conf42:JavaScript, devsecops , mobile ...](https://conf42.com/javascript/)
[📣]
📅 5 juillet 2022
📍 Paris, France 🇫🇷

[NODES 2022](https://nodesconference.com/)
[📣]
📅 7 au 9 novembre 2022
📍 Londres, Royaume-Uni 🇬🇧

